package com.example.bibliotecaabc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaabcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaabcApplication.class, args);
	}

}
