package com.example.bibliotecaabc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaabcApplicationTests {

	@Test
	void contextLoads() {
	}

}
